package backEnd;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.nio.channels.*;

public class Wallet {
    /**
     * The RandomAccessFile of the wallet file
     */
    private RandomAccessFile file;
    private FileChannel fileChannel;
    private FileLock fileLock;

    /**
     * Creates a Wallet object
     * <p>
     * A Wallet object interfaces with the wallet RandomAccessFile
     */
    public Wallet() throws Exception {
        this.file = new RandomAccessFile(new File("backEnd/wallet.txt"), "rw");
        this.fileChannel = file.getChannel();
    }

    /**
     * Gets the wallet balance.
     *
     * @return The content of the wallet file as an integer
     */
    public int getBalance() throws IOException {
        this.file.seek(0);
        try {
            fileLock = fileChannel.lock();
            return Integer.parseInt(this.file.readLine());
        } finally {
            if (fileLock != null && fileLock.isValid()){
                fileLock.release();
            }
        }
    }

    /**
     * Sets a new balance in the wallet
     *
     * @param newBalance new balance to write in the wallet
     */
    private void setBalance(int newBalance) throws Exception {
        this.file.setLength(0);
        String str = Integer.valueOf(newBalance).toString() + '\n';
        this.file.writeBytes(str);

    }

    public boolean safeWithdraw(int valueToWithdraw) throws Exception {
        try {
            int balance = getBalance();
            // Acquire the lock
            fileLock = fileChannel.lock();
            // Check if sufficient balance
            if (valueToWithdraw <= balance) {
                // Simulate processing time
                Thread.sleep(5000);
                // Update balance
                setBalance(balance - valueToWithdraw);
                return true;
            } else {
                return false;
            }
        } finally {
            // Release the lock in a finally block to ensure cleanup
            if (fileLock != null && fileLock.isValid()) {
                fileLock.release();
            }
        }
    }

    /**
     * Closes the RandomAccessFile in this.file
     */
    public void close() throws Exception {
	this.file.close();
    }
}
