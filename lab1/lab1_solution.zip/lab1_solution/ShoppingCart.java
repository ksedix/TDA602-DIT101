import java.util.Scanner;
import backEnd.*;
/*
 * 1. print the current balance of the user
 * 2. print the product list and their prices
 * 3. print the current pocket of the user
 * 4. ask a product to buy
 * 5. check if the amount of credits is enough, if not stop the execution.
 * 6. otherwise, withdraw the price of the product from the wallet.
 * 7. add the name of the product to the pocket file.
 * 8. repeat the steps until the user exits
 */
public class ShoppingCart {

    private static void print(Wallet wallet, Pocket pocket) throws Exception {
        //Step 1
        System.out.println("Your current balance is: " + wallet.getBalance() + " credits.");
        //Step 2
        System.out.println(Store.asString());
        //Step 3
        System.out.println("Your current pocket is:\n" + pocket.getPocket());
    }

    private static String scan(Scanner scanner) throws Exception {
        //Step 4
        System.out.print("What do you want to buy? (type quit to stop) ");
        return scanner.nextLine();
    }

    public static void main(String[] args) throws Exception {
        Wallet wallet = new Wallet();
        Pocket pocket = new Pocket();
        Scanner scanner = new Scanner(System.in);

        print(wallet, pocket);
        String product = scan(scanner);

        /*
       - check if the amount of credits is enough, if not stop the execution.
       - otherwise, withdraw the price of the product from the wallet.
       - add the name of the product to the pocket file.
       - print the new balance.
         */
        while(!product.equals("quit")){
            int price = Store.getProductPrice(product);

            //Step 5
/*          int balance = wallet.getBalance();
            if (balance>price){
                //Step 6
                int newBalance = balance - price;
                Thread.sleep(5000)
                wallet.setBalance(newBalance);
                //Step 7
                pocket.addProduct(product);
            } else {
                break;
            }*/

            if (wallet.safeWithdraw(price)){
                pocket.addProduct(product);
            } else
            {
                break;
            }

            //Step 8
            // Just to print everything again...
            print(wallet, pocket);
            product = scan(scanner);
        }
    }
}